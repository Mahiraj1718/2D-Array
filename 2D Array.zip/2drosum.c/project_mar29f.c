#include<stdio.h> 
int main() 
    { 
    int i,j; 
    int a[20][20]; 
    int r,c;
    int r1,temp=0;
    printf("\nenter the no of row and column:-\n"); 
    scanf("%d%d",&r,&c); 
    printf("\nENTER THE ARRAY:-\n"); 
    for(i=0;i<r;i++) 
        { 
        for(j=0;j<c;j++) 
            { 
            scanf("%d",&a[i][j]); 
            } 
        } 
    printf("\nDISPLAY THE ARRAY:-\n"); 
    for(i=0;i<r;i++) 
        { 
        for(j=0;j<c;j++) 
            { 
            printf("\t%d",a[i][j]); 
            } 
        printf("\n"); 
        } 
    for(i=0;i<r; ) 
        { temp=0;
        for(j=0;j<c;j++)
        { 
            temp=temp+a[i][j]; 
           
            } 
   
  
     
    printf("\nSUM OF ROW ELEMENT ARE:-%d",temp); 
   i++;
     }
    }
