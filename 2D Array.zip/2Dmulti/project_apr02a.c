#include<stdio.h> 
int main() 
    { 
    int i,j,k=0; 
    int a[10][10],b[10][10],m[20][20],temp[10][10]; 
    int r,c;
     printf("\nENTER THE NO OF ROWS AND COLUMN:-\n");
     scanf("%d%d",&r,&c); 
    printf("\nENTER THE FIRST ARRAY:-\n"); 
    for(i=0;i<r;i++) 
        { 
        for(j=0;j<c;j++) 
            { 
            scanf("%d",&a[i][j]); 
            } 
        } 
    printf("\nDISPLAY THE FIRST ARRAY:-\n"); 
    for(i=0;i<r;i++) 
        { 
        for(j=0;j<c;j++) 
            { 
            printf("\t%d",a[i][j]); } printf("\n"); 
        } 
    printf("\nENTER THE SECOND ARRAY:-\n"); 
    for(i=0;i<r;i++) 
        { 
        for(j=0;j<c;j++) 
            { 
            scanf("%d",&b[i][j]); 
            } 
        } 
    printf("\nDISPLAY THE SECOND ARRAY:-\n"); 
    for(i=0;i<r;i++) 
        { 
        for(j=0;j<c;j++) 
            { 
            printf("\t%d",b[i][j]); 
            } 
        printf("\n"); 
        } 
    for(i=0;i<r;i++) 
        {
         temp[i][j]=0; 
        for(j=0;j<c;j++) 
            {
             for(k=0;k<3;k++) 
            {
                temp[i][j]=temp[i][j]+a[i][k]*b[k][j];
                m[i][j]=temp[i][j];
            }
         }
        
     }
    
    printf("\nMULTIFICATION ARRAY ARE:-\n");
    for(i=0;i<r;i++) 
        { 
        for(j=0;j<c;j++) 
            {
            
            printf("\t%d",m[i][j]);
        }
        printf("\n");
  }  
}    