#include<stdio.h> 
int main() 
    { 
    int i,j; 
    int a[20][20]; 
    int r,c,prod=1; 
    printf("\nenter the no of row and column:-\n"); 
    scanf("%d%d",&r,&c); 
    printf("\nENTER THE ARRAY:-\n"); 
    
   for(i=0;i<r;i++) 
        { 
        for(j=0;j<c;j++) 
            { 
            scanf("%d",&a[i][j]); 
            } 
        } 
    printf("\nDISPLAY THE ARRAY:-\n"); 
    for(i=0;i<r;i++) 
        { 
        for(j=0;j<c;j++) 
            { 
            printf("\t%d",a[i][j]); 
            } 
        printf("\n"); 
        } 
    
    for(i=0;i<r;i++) 
        { 
        for(j=0;j<c;j++) 
            { 
            prod=prod*a[i][j]; 
            } 
        } 
    printf("PRODUCT OF ELEMENT ARE:-%d",prod); 
    }