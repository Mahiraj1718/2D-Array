#include<stdio.h> 
int main() 
    { 
    int i,j; 
    int a[20][20],b[10][10];
    int r,c;
    printf("\nenter the no of row and column:-\n"); 
    scanf("%d%d",&r,&c); 
    printf("\nENTER THE ARRAY:-\n"); 
    for(i=0;i<r;i++) 
        { 
        for(j=0;j<c;j++) 
            { 
            scanf("%d",&a[i][j]); 
            } 
        } 
    printf("\nDISPLAY THE ARRAY:-\n"); 
    for(i=0;i<r;i++) 
        { 
        for(j=0;j<c;j++) 
            { 
            printf("\t%d",a[i][j]); 
            } 
        printf("\n"); 
        } 
    printf("\nTRANPOSE ARRAY ARE:-\n");
    for(i=0;i<r;i++) 
        { 
        for(j=0;j<c;j++) 
           {
            if(i==j)
            {
                b[i][j]=a[i][j];
                printf("\t%d",b[i][j]);
            }
            else if(i<j||i>j)
            {
                b[i][j]=a[j][i];
                printf("\t%d",b[i][j]);
            }
       
        }
        printf("\n");
    }
  }  