#include<stdio.h> 
int main() 
    {
     int i,j; 
    int a[20][20]; 
    int r,c,flag=0;
     printf("\nenter the no of row and column:-\n"); 
    scanf("%d%d",&r,&c);
     printf("\nENTER THE ARRAY:-\n"); 
    for(i=0;i<r;i++) 
        { 
        for(j=0;j<c;j++) 
            { 
            scanf("%d",&a[i][j]); 
            } 
        } 
    printf("\nDISPLAY THE ARRAY:-\n"); 
    for(i=0;i<r;i++) 
        { 
        for(j=0;j<c;j++) 
            { 
            printf("\t%d",a[i][j]); 
            } 
        printf("\n"); 
        } 
    for(i=0;i<r;i++) 
        { 
        for(j=0;j<c;j++) 
            { 
            if(i==j&&a[i][j]!=1) 
                { 
                flag=1; 
                break; 
                } 
            else if(i!=j&&a[i][j]!=0)
             { 
                flag=1;
                 break; 
                }
             }
         } 
    if(flag==0) 
        { printf("\nTHIS IS IDENTITY  MATRIX");
         }
     else
     printf("\nNOT IDENTITY MATRIX");
 } 