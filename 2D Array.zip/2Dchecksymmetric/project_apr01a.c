#include<stdio.h> 
int main() 
    { 
    int i,j,flag=0; 
    int a[10][10],b[10][10]; 
    int r,c; 
    printf("\nENTER THE NO OF ROW AND COLUMN:-\n"); 
    scanf("%d%d",&r,&c); 
    printf("\nENTER THE ARRAY:-\n"); 
    for(i=0;i<r;i++) 
        { 
        for(j=0;j<c;j++) 
            { 
            scanf("%d",&a[i][j]);
             } 
        } 
    printf("\nDISPLAY THE ARRAY:-\n"); 
    for(i=0;i<r;i++) 
       {
         for(j=0;j<c;j++) 
            {
             printf("\t%d",a[i][j]); 
            } 
        printf("\n"); 
        } 
    for(i=0;i<r;i++) 
        { 
        for(j=0;j<c;j++) 
            { 
            if(i==j&&a[i][j]!=a[i][j])
            {
               flag=1;
                break; 
            }
            
          else if(i!=j&&a[i][j]!=a[j][i]) 
                {
                 flag=1; 
                break;
                } 
            } 
        } 
    if(flag==0) 
        { 
        printf("\nTHIS IS SYMMETRIC MATRIX"); 
        } 
    else 
    printf("\nNOT SYMMETRIC MATRIX"); 
 }