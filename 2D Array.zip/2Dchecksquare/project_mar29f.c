#include<stdio.h>
int main()
{
    int i,j,r,c;
    int a[10][10];
   printf("\nENTER THE NO OF ROW AND COLUMN:-\n");
    scanf("%d%d",&r,&c);
    
  printf("\nENTER THE ARRAY:-\n");
        for(i=0;i<r;i++)
        {
            for(j=0;j<c;j++)
            {
                scanf("%d",&a[i][j]);
            }
        }
    printf("\nDISPLAY ARRAY ARE:-\n");
    for(i=0;i<r;i++)
    {
        for(j=0;j<c;j++)
        {
            printf("\t%d",a[i][j]);
        }
        printf("\n");
    }
    if(r==c)
    {
   printf("\nIT IS SQUARE MATRIX");
     }
  else
        printf("\nNOT A SQUARE MATRIX");
    
    }